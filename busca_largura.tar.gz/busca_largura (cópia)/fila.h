#ifndef __fila_h
#define __fila_h

#include "definicoes.h"

void enfileirar(int *fila, int);
int desenfileirar(int *fila);
void printFila(int *fila, int);
#endif
