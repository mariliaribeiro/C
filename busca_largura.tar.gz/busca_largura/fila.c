#include "fila.h"

void enfileirar(Fila *fila, int s){       
    int fim = fila->tamanho;    
    
    fila->v[fim] = s;
    fila->tamanho++;
    //printFila(fila);
}
    
int desenfileirar(Fila *fila){
    int i;   
    int desenfileirado = fila->v[0];
    
    for (i = 1; i < fila->tamanho; i++)
        fila->v[i-1] = fila->v[i];
    
    
    fila->v[fila->tamanho] = NULL;
    fila->tamanho--;
    //printFila(fila);
    return desenfileirado;
}


void printFila(Fila *fila){
    int i;
    printf("\nFila:[ ");
    if (fila != NULL){
        for(i = 0; i < fila->tamanho-1; i ++){
            printf("%d ", fila->v[i]);
        }
    }
    printf("]");
}
