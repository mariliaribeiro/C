#ifndef __busca_h
#define __busca_h

#include "definicoes.h"

void buscaLargura(Grafo*, int s);
void printBusca(int cor[], int distancia[], int pai[], Grafo *);
Fila *criaFila();

#endif
