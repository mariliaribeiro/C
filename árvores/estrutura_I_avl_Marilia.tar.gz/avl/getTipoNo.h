#ifndef __getTipoNo_h
#define __getTipoNo_h

#include "definicoes.h"

int isFolha(Node*);
int isSubFolha(Node*);
int isPaiDoisFilhos(Node*);
int isRaiz(Arvore*, Node*);

#endif
