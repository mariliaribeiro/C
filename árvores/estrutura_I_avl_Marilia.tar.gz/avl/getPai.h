#ifndef __getPai_h
#define __getPai_h

#include "definicoes.h"

Node* getPai(Node*, int);

#endif
