#ifndef __buscar_h
#define __buscar_h

#include "definicoes.h"

Node* buscar(Node*, int);
void imprimeBusca(Node*, int);

#endif
