#ifndef __inserir_h
#define __inserir_h

#include "definicoes.h"

Node* inserirNo(int);
Node* inserir(Node*,int);
#endif
