#ifndef __ordenar_h
#define __ordenar_h

#include "definicoes.h"

void preOrdem(Node*);
void posOrdem(Node*);
void emOrdem(Node*);
#endif
