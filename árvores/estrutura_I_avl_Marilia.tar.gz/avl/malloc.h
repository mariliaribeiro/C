#ifndef __malloc_h
#define __malloc_h

#include "definicoes.h"

Arvore* criaArvore();
Node* criaNode();
Altura* criaAltura();

#endif
