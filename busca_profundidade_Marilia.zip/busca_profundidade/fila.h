#ifndef __fila_h
#define __fila_h

#include "definicoes.h"

void enfileirar(Fila *fila, No *no);
No *desenfileirar(Fila *fila);
void printFila(Fila *fila);
#endif
